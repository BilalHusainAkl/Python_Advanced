#WPP to print extension of given file.
filename = input("Input the filename: ")
file_extension = filename.split(".")
print ("The extension of the file is : " +str((file_extension)[-1]))
