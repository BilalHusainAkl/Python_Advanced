print(" I wandered lonely as a Cloud, \n\t That floats on high o'er vales and hills, \n\t\t When all at once I saw a Crowd, \n\t\t\t A host, of golden daffodils.")
