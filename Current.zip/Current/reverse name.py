#WPP to reverse name order.
fname=input("Enter your first name ")
lname=input("Enter your last name ")
print("Hello "+lname+" "+fname)
