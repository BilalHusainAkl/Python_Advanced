from math import pi
r=float(input("Enter the value of radius : "))
print("The area of circle is : "+str(pi*r**2))
