import datetime

x = datetime.datetime(2020, 5, 17 , 4 ,5,5)

print(x)
