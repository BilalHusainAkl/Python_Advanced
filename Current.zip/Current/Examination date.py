import datetime
exam = datetime.datetime(2022,5,16,11,00,00)
print("The exam will start from", exam, "AM")
