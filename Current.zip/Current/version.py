import sys
print("Python version")
print (sys.version)
print("Version Info")
print(sys.version_info)
