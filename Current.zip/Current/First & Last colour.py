mycolour_list=["White","Green","Yellow","Violet"]
print("%s\n%s"%(mycolour_list[0],mycolour_list[-1]))
