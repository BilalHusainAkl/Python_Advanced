#WPP to convert to convert temperature from Celsius to Fahrenheit.
c=int(input("Enter temperature in Celsius : "))
f=(c*1.8)+32
print("Temperature in Fahrenheit is : ",f)